import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
app.use(cors());
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let shipments = {
  "TESLA-USA-2410-784632": {
    status: "In Transit",
    location: "Los Angeles, CA",
    lastUpdated: new Date().toLocaleString()
  }
};

// Serve frontend
app.use(express.static(__dirname));

// API endpoint
app.get("/track/:id", (req, res) => {
  const id = req.params.id;
  const shipment = shipments[id];
  if (!shipment) return res.status(404).json({ error: "Tracking ID not found" });
  res.json(shipment);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
